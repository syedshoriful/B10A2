## Figma Link 

[Figma Link] (https://www.figma.com/design/Hb31V8a9AdEXkjc0P4gRWm/Theme%3A-Fitness-Related-website?node-id=0-1&t=497wT8tcrhXU6Hiy-1)